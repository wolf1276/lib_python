print("Hello")
print("Guys after a long run I am able to integrate the infra of python - VS Code - GIT")
print("Guys finally I am able to integrate the infra of python - VS Code - GIT - Jenkins")
print("Last test if actively configured")